
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginald3b387f4f5efe74d7afe13be62871c47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3b387f4f5efe74d7afe13be62871c47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.header','data' => ['title' => ''.e(__('dashboard.gallery')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e(__('dashboard.gallery')).'']); ?>
        <div class="text-xl font-bold"><?php echo e(__('dashboard.gallery')); ?></div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $attributes = $__attributesOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $component = $__componentOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__componentOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>
    
    <div class="grid sm:grid-cols-1 md:grid-cols-2 gap-2">
        <!-- Add New Image Section -->
        <div class="col-span-1 bg-white rounded-lg shadow p-6 max-h-96">
            <form action="<?php echo e(route('dashboard.slider_images.store')); ?>" method="POST" id="addImageForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label for="type" class="block text-sm font-medium"><?php echo e(__('dashboard.type')); ?></label>
                    <select id="type" name="type" class="w-full mt-1 block border-gray-300 rounded-md bg-gray-200 py-1 px-2">
                        <option value="" hidden disabled selected ><?php echo e(__('dashboard.select')); ?></option>
                        <option value="channel"><?php echo e(__('dashboard.channel')); ?></option>
                        <option value="partner"><?php echo e(__('dashboard.partner')); ?></option>
                        <option value="journal"><?php echo e(__('dashboard.journal')); ?></option>
                    </select>
                </div>
                <div class="mb-4">
                    <label for="image" class="block text-sm font-medium"><?php echo e(__('dashboard.add_image')); ?></label>
                    <input type="file" id="image" name="image" accept="image/*" class="mt-1 block w-full border-gray-300 rounded-md bg-gray-200 py-1 px-2">
                </div>
                <div class="mb-4">
                    <img id="imagePreview" class="mt-2 w-24 h-16 object-cover hidden">
                </div>
                <div class="mb-4">
                    <button type="submit" id="addImageBtn" class="px-4 py-2 bg-[#452810] text-white rounded"><?php echo e(__('dashboard.submit')); ?></button>
                </div>
            </form>

                <?php if($errors->any()): ?>
                    <div class="border-red-500 bg-red-300 p-4 rounded border-2">
                        <ul class="list-disc px-2">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
        
        </div>

        <!-- Images Table -->
        <div class="col-span-1 bg-white rounded-lg shadow p-6 h-full ">
            <table class="shadow w-full rounded-lg overflow-hidden">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="py-2 px-4 text-start">#</th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.image')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.type')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.actions')); ?></th>
                    </tr>
                </thead>
                <tbody id="tableData">
                    <?php $__currentLoopData = $slider_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="row-<?php echo e($slider_image->id); ?>" class="border-t border-gray-200">
                            <td class="py-2 px-4 text-start"><?php echo e($loop->iteration); ?></td>
                            <td class="py-2 px-4 text-start">
                                <img src="<?php echo e($slider_image->image); ?>" class="w-24 h-24 object-cover">
                            </td>
                            <td class="py-2 px-4 text-start">
                                <?php echo e(__('dashboard.'.$slider_image->type)); ?>

                            </td>
                            <td class="py-2 px-4 gap-2">
                                <button onclick="openModal(this)" data-modal-id="deleteImg" data-src="<?php echo e($slider_image->image); ?>" data-id="<?php echo e($slider_image->id); ?>" class="px-2 py-1 text-xs bg-red-500 rounded text-white"><?php echo e(__('dashboard.delete')); ?></button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Delete Image Modal -->
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['title' => ''.e(__('dashboard.delete_image')).'','id' => 'deleteImg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e(__('dashboard.delete_image')).'','id' => 'deleteImg']); ?>
        <div>
            <div><?php echo e(__('dashboard.delete_image_confirmation')); ?></div>
            <img id="deleteImagePreview" class="w-24 h-24 object-cover mt-4">
            <input type="hidden" id="deleteImageId">
            <div class="flex justify-between border-t border-gray-300 pt-2">
                <button type="button" id="deleteImageBtn" class="px-2 py-1 text-xs bg-red-500 rounded text-white"><?php echo e(__('dashboard.delete')); ?></button>
                <button type="button" onclick="closeModal('deleteImg')" class="px-2 py-1 text-xs bg-white rounded text-black "><?php echo e(__('dashboard.close')); ?></button>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

    <?php echo $__env->make('dashboard.inc._toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    // Function to preview image before upload
    document.getElementById('image').addEventListener('change', function(event) {
        const image = event.target.files[0];
        const reader = new FileReader();

        reader.onload = function(e) {
            const preview = document.getElementById('imagePreview');
            preview.src = e.target.result;
            preview.classList.remove('hidden');
        };

        if (image) {
            reader.readAsDataURL(image);
        }
    });

    // Function to open modal and set image details for deletion
    function openModal(button) {
        const modalId = button.getAttribute('data-modal-id');
        const imageSrc = button.getAttribute('data-src');
        const id = button.getAttribute('data-id');

        const modal = document.getElementById(modalId);
        modal.classList.add('block');
        modal.classList.remove('hidden');

        if (modalId === 'deleteImg') {
            document.getElementById('deleteImagePreview').src = imageSrc;
            document.getElementById('deleteImageId').value = id;
        }
    }

    // Function to delete image
    document.getElementById('deleteImageBtn').addEventListener('click', function() {
        const id = document.getElementById('deleteImageId').value;

        fetch("<?php echo e(route('dashboard.slider_images.delete')); ?>", {
            method: "Delete",
            body: JSON.stringify({ id: id }),
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
            },
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                toast('toast-success', data.message);
                document.getElementById(`row-${id}`).remove();
                closeModal('deleteImg');
            }
        })
        .catch(error => console.error('Error:', error));
    });

    // Close modal function
    function closeModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.add('hidden');
        modal.classList.remove('block');
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NeferitiWebsite\resources\views\dashboard\slider\index.blade.php ENDPATH**/ ?>