
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginald3b387f4f5efe74d7afe13be62871c47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3b387f4f5efe74d7afe13be62871c47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="text-xl font-bold"><?php echo e(__('dashboard.bookings_list')); ?></div>
    <div class="text-sm text-gray-500"><?php echo e(__('dashboard.booking_details')); ?></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $attributes = $__attributesOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $component = $__componentOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__componentOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>

<div class="bg-white rounded-lg shadow p-6 h-full">
    <h1 class="text-2xl font-bold mb-4"><?php echo e(__('dashboard.booking_details')); ?> - <?php echo e($booking['unique_id']); ?></h1>
    
    <div class="bg-white p-6 shadow rounded-lg">
        <h2 class="text-lg font-semibold"><?php echo e(__('dashboard.basic_info')); ?></h2>
        <div class="grid grid-cols-2 gap-4 mb-6">
            <div><strong><?php echo e(__('dashboard.status')); ?>:</strong> <?php echo e($booking['status']); ?></div>
            <div><strong><?php echo e(__('dashboard.source_ota')); ?>:</strong> <?php echo e($booking['ota_name']); ?></div>
            <div><strong><?php echo e(__('dashboard.reservation_id')); ?>:</strong> <?php echo e($booking['unique_id']); ?></div>
            <div><strong><?php echo e(__('dashboard.booking_id')); ?>:</strong> <?php echo e($booking['booking_id']); ?></div>
            <div><strong><?php echo e(__('dashboard.booked_at')); ?>:</strong> <?php echo e(\Carbon\Carbon::parse($booking['inserted_at'])->format('l, F j, Y')); ?></div>
            <div><strong><?php echo e(__('dashboard.property')); ?>:</strong> <?php echo e($booking['property_id']); ?></div>
        </div>

        <h2 class="text-lg font-semibold mb-2"><?php echo e(__('dashboard.checkin_details')); ?></h2>
        <div class="grid grid-cols-2 gap-4 mb-6">
            <div><strong><?php echo e(__('dashboard.checkin_date')); ?>:</strong> <?php echo e($booking['arrival_date']); ?></div>
            <div><strong><?php echo e(__('dashboard.checkout_date')); ?>:</strong> <?php echo e($booking['departure_date']); ?></div>
            <div><strong><?php echo e(__('dashboard.nights')); ?>:</strong> 1</div>
            <div><strong><?php echo e(__('dashboard.rooms')); ?>:</strong> <?php echo e(count($booking['rooms'])); ?></div>
            <div><strong><?php echo e(__('dashboard.occupancy')); ?>:</strong> A: <?php echo e($booking['occupancy']['adults']); ?> C: <?php echo e($booking['occupancy']['children']); ?> I: <?php echo e($booking['occupancy']['infants']); ?></div>
        </div>

        <h2 class="text-lg font-semibold mb-2"><?php echo e(__('dashboard.customer')); ?></h2>
        <div class="grid grid-cols-2 gap-4 mb-6">
            <div><strong><?php echo e(__('dashboard.name')); ?>:</strong> <?php echo e($booking['customer']['name']); ?> <?php echo e($booking['customer']['surname']); ?></div>
            <div><strong><?php echo e(__('dashboard.email')); ?>:</strong> <?php echo e($booking['customer']['mail']); ?></div>
            <div><strong><?php echo e(__('dashboard.phone')); ?>:</strong> <?php echo e($booking['customer']['phone']); ?></div>
            <div><strong><?php echo e(__('dashboard.country')); ?>:</strong> <?php echo e($booking['customer']['country']); ?></div>
        </div>

        <h2 class="text-lg font-semibold mb-2"><?php echo e(__('dashboard.room_details')); ?></h2>
        <?php $__currentLoopData = $booking['rooms']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-gray-100 p-4 rounded-lg mb-4">
            <h3 class="font-semibold"><?php echo e(__('dashboard.room_type')); ?>: <?php echo e($room['meta']['room_type_code']); ?></h3>
            <p><strong><?php echo e(__('dashboard.price')); ?>:</strong> <?php echo e($room['amount']); ?> <?php echo e($booking['currency']); ?></p>
            <p><strong><?php echo e(__('dashboard.meal_plan')); ?>:</strong> <?php echo nl2br(e($room['meta']['meal_plan'])); ?></p>
            <p><strong><?php echo e(__('dashboard.smoking_preferences')); ?>:</strong> <?php echo e($room['meta']['smoking_preferences']); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <h2 class="text-lg font-semibold mb-2"><?php echo e(__('dashboard.guarantee')); ?></h2>
        <div class="grid grid-cols-2 gap-4 mb-6">
            <div><strong><?php echo e(__('dashboard.card_type')); ?>:</strong> <?php echo e($booking['guarantee']['card_type']); ?></div>
            <div><strong><?php echo e(__('dashboard.card_number')); ?>:</strong> <?php echo e($booking['guarantee']['card_number']); ?></div>
            <div><strong><?php echo e(__('dashboard.expiration_date')); ?>:</strong> <?php echo e($booking['guarantee']['expiration_date']); ?></div>
            <div><strong><?php echo e(__('dashboard.cardholder_name')); ?>:</strong> <?php echo e($booking['guarantee']['cardholder_name']); ?></div>
        </div>

        <h2 class="text-lg font-semibold mb-2"><?php echo e(__('dashboard.notes')); ?></h2>
        <div class="p-4 bg-gray-50 rounded-lg mb-6">
            <?php echo nl2br(e($booking['notes'])); ?>

        </div>

        <h2 class="text-lg font-semibold mb-2"><?php echo e(__('dashboard.price_breakdown')); ?></h2>
        <?php $__currentLoopData = $booking['rooms']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-gray-100 p-4 rounded-lg mb-4">
            <p><strong><?php echo e(__('dashboard.room_price')); ?>:</strong> <?php echo e($room['amount']); ?> <?php echo e($booking['currency']); ?></p>
            <?php $__currentLoopData = $room['taxes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><strong><?php echo e($tax['name']); ?>:</strong> <?php echo e($tax['total_price']); ?> <?php echo e($booking['currency']); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <h2 class="text-lg font-semibold mb-2"><?php echo e(__('dashboard.total_amount')); ?></h2>
        <div class="p-4 bg-gray-50 rounded-lg">
            <strong><?php echo e($booking['amount']); ?> <?php echo e($booking['currency']); ?></strong>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NeferitiWebsite\resources\views\dashboard\bookings\show.blade.php ENDPATH**/ ?>