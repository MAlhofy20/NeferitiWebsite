
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginald3b387f4f5efe74d7afe13be62871c47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3b387f4f5efe74d7afe13be62871c47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="text-xl font-bold"><?php echo e(__('dashboard.bookings_list')); ?></div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $attributes = $__attributesOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $component = $__componentOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__componentOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>

    <div class="bg-white rounded-lg shadow p-6 h-full">
        <!-- جدول الحجوزات -->
        <div>
            <table class="shadow w-full rounded-lg overflow-hidden">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.ota_reservation_code')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.ota_name')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.status')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.customer_username')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.interested_At')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.view')); ?></th>
                    </tr>
                </thead>
                <tbody id="tableData">
                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="row-<?php echo e($booking['id']); ?>" class="border-t border-gray-200">
                            <td class="py-2 px-4 text-start items-center"><?php echo e($booking['attributes']['ota_reservation_code']); ?></td>
                            <td class="py-2 px-4 text-start items-center"><?php echo e($booking['attributes']['ota_name']); ?></td>
                            <td class="py-2 px-4 text-start items-center"><?php echo e($booking['attributes']['status']); ?></td>
                            <td class="py-2 px-4 text-start items-center"><?php echo e($booking['attributes']['customer']['name']); ?></td>
                            <td class="py-2 px-4 text-start items-center"><?php echo e(\Carbon\Carbon::parse($booking['attributes']['inserted_at'])->format('Y-m-d')); ?></td>
                            <td class="py-2 px-4 text-start items-center">
                                <button onclick="window.location.href = '<?php echo e(route('dashboard.bookings.show', $booking['id'])); ?>'" 
                                    class="px-2 py-1 text-xs bg-gray-300 rounded text-black"><?php echo e(__('dashboard.view')); ?></button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <!-- Pagination -->
            <div class="flex items-center mt-4 gap-2 text-xs">
                <?php if($currentPage > 1): ?>
                    <a href="<?php echo e(route('dashboard.bookings.index', ['page' => $currentPage - 1])); ?>"
                        class="px-3 py-1 text-white rounded bg-gray-800"><?php echo e(__('dashboard.previous')); ?></a>
                <?php endif; ?>
                <span class="font-semibold text-lg"><?php echo e($currentPage); ?></span>
                <?php if($currentPage < $totalPages): ?>
                    <a href="<?php echo e(route('dashboard.bookings.index', ['page' => $currentPage + 1])); ?>"
                        class="px-3 py-1 text-white rounded bg-gray-800"><?php echo e(__('dashboard.next')); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NeferitiWebsite\resources\views\dashboard\bookings\index.blade.php ENDPATH**/ ?>