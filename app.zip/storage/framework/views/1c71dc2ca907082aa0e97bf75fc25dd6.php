<div class="flex justify-between items-center mb-5">
    <div class="flex gap-2 items-center">
        <button type="button" onclick="openNav('MainSidenav')"
            class="MainSidenav inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden ">
            <svg class="w-5 h-5 MainSidenav" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                viewBox="0 0 17 14">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M1 1h15M1 7h15M1 13h15" />
            </svg>
        </button>
        <div id="MainSidenav"
            class="itsSideMenu  fixed z-50 inset-y-0 right-0  w-0 bg-black text-white transition-width duration-500 pt-16 overflow-y-scroll shadow-2xl">
            <a role="button" onclick="closeNav('MainSidenav')" class="absolute top-0 right-6 text-4xl">&times;</a>
            <div class="space-y-1">
                <a href="<?php echo e(route('dashboard.home')); ?>" class="flex items-center text-white <?php echo e(Route::currentRouteName() == 'dashboard.home' ? 'bg-primary' : ''); ?> hover:bg-primary rounded-lg px-3 py-3">
                    <i class="fa-solid fa-house mx-2"></i>
                    <?php echo e(__('dashboard.home')); ?>

                </a>
                <a href="<?php echo e(route('dashboard.admin.index')); ?>" class="flex items-center text-white <?php echo e(Route::is('dashboard.admin.*') ? 'bg-primary' : ''); ?> hover:bg-primary rounded-lg px-3 py-3">
                    <i class="fa-solid fa-house mx-2"></i>
                    <?php echo e(__('dashboard.admin.index')); ?>

                </a>
                
                

                
                <a href="<?php echo e(route('dashboard.products.index')); ?>" class="flex items-center text-white <?php echo e(Route::is('dashboard.products.*') ? 'bg-primary' : ''); ?> hover:bg-primary rounded-lg px-3 py-3">
                    <i class="fa-solid fa-tags mx-2"></i>
                    <?php echo e(__('dashboard.products.index')); ?>

                </a>
                <a href="<?php echo e(route('dashboard.partners.index')); ?>" class="flex items-center text-white <?php echo e(Route::is('dashboard.partners.*') ? 'bg-primary' : ''); ?> hover:bg-primary rounded-lg px-3 py-3">
                    <i class="fa-solid fa-handshake mx-2"></i>
                    <?php echo e(__('dashboard.partners.index')); ?>

                </a>

                
                

                
                <a href="<?php echo e(route('dashboard.settings.index')); ?>" class="flex items-center text-white <?php echo e(Route::is('dashboard.settings.*') ? 'bg-primary' : ''); ?> hover:bg-primary rounded-lg px-3 py-3">
                    <i class="fa-solid fa-gear mx-2"></i>
                    <?php echo e(__('dashboard.settings.index')); ?>

                </a>

                
                <a href="<?php echo e(route('dashboard.profile')); ?>" class="flex items-center text-white <?php echo e(Route::is('dashboard.profile.*') ? 'bg-primary' : ''); ?> hover:bg-primary rounded-lg px-3 py-3">
                    <i class="fa-solid fa-user mx-2"></i>
                    <?php echo e(__('dashboard.profile')); ?>

                </a>
                

                <?php if(lang('ar')): ?>
                <a href="<?php echo e(route('lang', 'en')); ?>" class="flex items-center text-white bg-primary hover:bg-yellow-600 rounded-lg px-3 py-3">
                    <i class="fa-solid fa-earth-americas mx-2"></i><?php echo e(__('dashboard.change_language')); ?>

                </a>
                <?php else: ?>
                <a href="<?php echo e(route('lang', 'ar')); ?>" class="flex items-center text-white bg-primary hover:bg-yellow-600 rounded-lg px-3 py-3">
                    <i class="fa-solid fa-earth-americas mx-2"></i><?php echo e(__('dashboard.change_language')); ?>

                </a>
                <?php endif; ?>
                <a onclick="document.getElementById('logoutForm').submit()" role="button" class="flex items-center text-white bg-primary hover:bg-yellow-600 rounded-lg px-3 py-3">
                    <i class="fas fa-sign-out-alt mx-2 w-5"></i> <?php echo e(__('dashboard.logout')); ?>

                </a>

            </div>
        
            <form id="logoutForm" action="<?php echo e(route('dashboard.logout')); ?>" method="POST" class="hidden">
                <?php echo csrf_field(); ?>
            </form>
        </div>
        <?php echo e($slot); ?>

    </div>
    <div class="hidden md:flex items-center gap-2">
        <div class="rounded-lg w-10 h-10 bg-black flex justify-center items-center">
            <i class="fas fa-bell text-2xl text-white"></i>
        </div>
        <div role="button" onclick="location.href='<?php echo e(route('dashboard.profile')); ?>'" class="flex items-center gap-2">
            <img src="<?php echo e(auth('admin')->user()->image ? asset(auth('admin')->user()->image) : asset('dash/images/face.jpg')); ?>" alt="User Avatar" class="rounded-lg w-10 h-10">
            <div>
                <p class="text-sm text-gray-500"><?php echo e(__('dashboard.welcome')); ?></p>
                <span><?php echo e(auth('admin')->user()->name); ?></span>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\NeferitiWebsite\resources\views\components\dashboard\header.blade.php ENDPATH**/ ?>