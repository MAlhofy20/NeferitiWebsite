<!DOCTYPE html>
<html>
<head>
    <title>Notification Email</title>
</head>
<body>
    <h1>Test Notification</h1>
    <p><?php echo e($messageContent); ?></p>
</body>
</html>
<?php /**PATH C:\laragon\www\NeferitiWebsite\resources\views\emails\notification.blade.php ENDPATH**/ ?>