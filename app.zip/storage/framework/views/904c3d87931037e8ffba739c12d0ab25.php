<div class="bg-primary p-6 flex-col justify-between h-screen fixed hidden md:flex md:w-[250px]">
    <div>
        <div role="button" onclick="location.href='<?php echo e(route('dashboard.home')); ?>'"
            class="flex items-center mb-8 justify-center">
            
            <img src="<?php echo e(asset('dash/images/4.png')); ?>">
        </div>
        <nav class="space-y-1 max-h-96 overflow-y-scroll scrollbar-hide">
            <a href="<?php echo e(route('dashboard.home')); ?>"
                class="flex items-center  <?php echo e(Route::currentRouteName() == 'dashboard.home' ? 'bg-white' : 'text-white'); ?> hover:bg-secondary  rounded-lg px-3 py-3">
                <i class="fa-solid fa-house mx-2"></i>
                <?php echo e(__('dashboard.home')); ?>

            </a>
            <a href="<?php echo e(route('dashboard.admin.index')); ?>"
                class="flex items-center  <?php echo e(Route::is('dashboard.admin.*') ? 'bg-white' : 'text-white'); ?> hover:bg-secondary  rounded-lg px-3 py-3">
                <i class="fa-solid fa-user-tie mx-2"></i>
                <?php echo e(__('dashboard.admins')); ?>

            </a>
            
            <a href="<?php echo e(route('dashboard.products.index')); ?>"
                class="flex items-center  <?php echo e(Route::is('dashboard.products.*') ? 'bg-white' : 'text-white'); ?> hover:bg-secondary  rounded-lg px-3 py-3">
                <i class="fa-solid fa-tags mx-2"></i>
                <?php echo e(__('dashboard.products')); ?>

            </a>
            <a href="<?php echo e(route('dashboard.projects.index')); ?>"
                class="flex items-center  <?php echo e(Route::is('dashboard.projects.*') ? 'bg-white' : 'text-white'); ?> hover:bg-secondary  rounded-lg px-3 py-3">
                <i class="fa-solid fa-building mx-2"></i>
                <?php echo e(__('dashboard.projects')); ?>

            </a>
            <a href="<?php echo e(route('dashboard.blogs.index')); ?>"
                class="flex items-center  <?php echo e(Route::is('dashboard.blogs.*') ? 'bg-white' : 'text-white'); ?> hover:bg-secondary  rounded-lg px-3 py-3">
                <i class="fa-solid fa-blog mx-2"></i>
                <?php echo e(__('dashboard.blogs')); ?>

            </a>
            <a href="<?php echo e(route('dashboard.testimonials.index')); ?>"
                class="flex items-center  <?php echo e(Route::is('dashboard.testimonials.*') ? 'bg-white' : 'text-white'); ?> hover:bg-secondary  rounded-lg px-3 py-3">
                <i class="fa-solid fa-comment mx-2"></i>
                <?php echo e(__('dashboard.testimonials')); ?>

            </a>
            <a href="<?php echo e(route('dashboard.partners.index')); ?>"
                class="flex items-center  <?php echo e(Route::is('dashboard.partners.*') ? 'bg-white' : 'text-white'); ?> hover:bg-secondary  rounded-lg px-3 py-3">
                <i class="fa-solid fa-handshake mx-2"></i>
                <?php echo e(__('dashboard.partners')); ?>

            </a>
             
            
            <a href="<?php echo e(route('dashboard.settings.index')); ?>"
                    class="flex items-center  <?php echo e(Route::is('dashboard.settings.*') ? 'bg-white' : 'text-white'); ?> hover:bg-secondary  rounded-lg px-3 py-3">
                    <i class="fa-solid fa-gear mx-2"></i>
                <?php echo e(__('dashboard.settings')); ?>

            </a>


            <a href="<?php echo e(route('dashboard.profile')); ?>"
                class="flex items-center  <?php echo e(Route::is('dashboard.profile.*') ? 'bg-white' : 'text-white'); ?> hover:bg-secondary  rounded-lg px-3 py-3">
                <i class="fa-solid fa-user mx-2"></i>
                <?php echo e(__('dashboard.profile')); ?>

            </a>

        </nav>
    </div>
    <div class="space-y-1 border-gray-700 pt-4">
        <?php if(lang('ar')): ?>
            <a href="<?php echo e(route('lang', 'en')); ?>"
                class="flex items-center  bg-white hover:bg-secondary rounded-lg px-3 py-3">
                <i class="fa-solid fa-earth-americas mx-2"></i><?php echo e(__('dashboard.change_language')); ?>

            </a>
        <?php else: ?>
            <a href="<?php echo e(route('lang', 'ar')); ?>"
                class="flex items-center  bg-white hover:bg-secondary rounded-lg px-3 py-3">
                <i class="fa-solid fa-earth-americas mx-2"></i><?php echo e(__('dashboard.change_language')); ?>

            </a>
        <?php endif; ?>
        <a onclick="document.getElementById('logoutForm').submit()" role="button"
            class="flex items-center  bg-white hover:bg-secondary rounded-lg px-3 py-3">
            <i class="fas fa-sign-out-alt mx-2 w-5"></i> <?php echo e(__('dashboard.logout')); ?>

        </a>

    </div>
    <form id="logoutForm" action="<?php echo e(route('dashboard.logout')); ?>" method="POST" class="hidden">
        <?php echo csrf_field(); ?>
    </form>

</div>
<?php /**PATH C:\laragon\www\NeferitiWebsite\resources\views\dashboard\inc\_sidebar.blade.php ENDPATH**/ ?>