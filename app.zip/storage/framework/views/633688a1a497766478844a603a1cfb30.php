<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginald3b387f4f5efe74d7afe13be62871c47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3b387f4f5efe74d7afe13be62871c47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.header','data' => ['title' => ''.e(__('dashboard.admins')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e(__('dashboard.admins')).'']); ?>
        <div class="text-xl font-bold"><?php echo e(__('dashboard.admins')); ?></div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $attributes = $__attributesOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $component = $__componentOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__componentOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>
    <div class="bg-white rounded-lg shadow p-6 h-full">
        <!-- Content here -->
        <button onclick="window.location.href = '<?php echo e(route('dashboard.admin.create')); ?>'"
            class="px-2 py-1 bg-black hover:bg-primary text-white mb-2 rounded-lg">
            <?php echo e(__('dashboard.create')); ?>

        </button>

        <table class="shadow w-full rounded-lg overflow-hidden">
            <thead>
                <tr class="bg-gray-200">
                    <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.name')); ?></th>
                    <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.email')); ?></th>
                    <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.actions')); ?></th>
                </tr>
            </thead>
            <tbody id="tableData">
                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="row-<?php echo e($admin->id); ?>" class="border-t border-gray-200">
                        <td class="py-2 px-4 text-start"><?php echo e($admin->name); ?></td>
                        <td class="py-2 px-4 text-start">
                            <?php echo e($admin->email); ?>

                        </td>
                        <td class="py-2 px-4 flex gap-2 items-center">
                            <a href="<?php echo e(route('dashboard.admin.edit', $admin->id)); ?>"  class="fa-solid fa-pen-to-square hover:text-blue-500"></a>

                            <?php if($admin->id != auth('admin')->user()->id): ?>
                            <div>
                                <form action="<?php echo e(route('dashboard.admin.destroy', $admin->id)); ?>" method="POST" id="deleteadminForm<?php echo e($admin->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <i role="button" onclick="confirmDelete('deleteadminForm<?php echo e($admin->id); ?>', '<?php echo e(lang()); ?>')"  class="fa-solid fa-trash hover:text-red-500"></i>
                                </form>
                                </div>
                            <?php endif; ?>


                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NeferitiWebsite\resources\views\dashboard\admin\index.blade.php ENDPATH**/ ?>