

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginald3b387f4f5efe74d7afe13be62871c47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3b387f4f5efe74d7afe13be62871c47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="text-xl font-bold"><?php echo e(__('dashboard.email_settings')); ?></div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $attributes = $__attributesOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $component = $__componentOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__componentOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>
    <div class="bg-white rounded-lg shadow p-6 h-full w-full md:w-1/2">
        <!-- Content here -->
        <div >
            <form method="post" action="<?php echo e(route('dashboard.email_settings.update')); ?>" class="w-full">
                <?php echo csrf_field(); ?>
                <p class="text-2xl font-bold mb-10 text-black"><i class="fa-solid fa-envelope mx-2"></i><?php echo e(__('dashboard.email_settings')); ?></p>

                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-4">
                        <label for="<?php echo e($setting->key); ?>" class="block mb-1 text-black"><?php echo e($setting->key); ?></label>
                        <input type="text" id="<?php echo e($setting->key); ?>" name="<?php echo e($setting->key); ?>" value="<?php echo e($setting->value); ?>"
                            class="w-full p-2 border bg-gray-100 rounded-lg">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="justify-center flex flex-col"></div>
                    <button type="submit"  class="disableBtn px-4 py-2 bg-[#FDCB16] hover:bg-[#E7D2B8] text-black rounded-lg "><?php echo e(__('dashboard.update')); ?></button>
                </div>

            </form>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NeferitiWebsite\resources\views\dashboard\email_settings.blade.php ENDPATH**/ ?>