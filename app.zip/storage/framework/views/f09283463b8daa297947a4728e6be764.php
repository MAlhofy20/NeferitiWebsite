
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginald3b387f4f5efe74d7afe13be62871c47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3b387f4f5efe74d7afe13be62871c47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="text-xl font-bold"><?php echo e(__('dashboard.facilities')); ?></div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $attributes = $__attributesOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $component = $__componentOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__componentOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>
    <div class="bg-white rounded-lg shadow p-6 h-full">
        <!-- Content here -->
        <div>
            <table class="shadow w-full rounded-lg overflow-hidden">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.name')); ?></th>
                        <th class="py-2 px-4 text-center"><?php echo e(__('dashboard.category')); ?></th>
                        <th class="py-2 px-4 text-center"><?php echo e(__('dashboard.type')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.actions')); ?></th>
                    </tr>
                </thead>
                <tbody id="tableData">
                    <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-t border-gray-200">
                            <td id="name_<?php echo e($fa->id); ?>" class="py-2 px-4 text-start"><?php echo e($fa->name_en . ' / ' . $fa->name_ar); ?></td>
                            <td  class="py-2 px-4 text-start">
                                <?php echo e($fa->category->name_en . ' / ' . $fa->category->name_ar); ?> </td>
                            <td class="py-2 px-4 text-center">
                                <?php echo e(__('dashboard.facilities_of_' . $fa->type)); ?>

                            </td>
                            <td class="py-2 px-4 text-start">
                                <div>
                                    <button onclick="openModal(this)"
                                    data-modal-id="editName"
                                    data-name-ar="<?php echo e($fa->name_ar); ?>"
                                    data-name-en="<?php echo e($fa->name_en); ?>"
                                    data-id="<?php echo e($fa->id); ?>"
                                    class="px-2 py-1 text-xs bg-gray-300 rounded text-black"><?php echo e(__('dashboard.update')); ?></button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['title' => ''.e(__('dashboard.edit_name')).'','id' => 'editName']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e(__('dashboard.edit_name')).'','id' => 'editName']); ?>
        <div>
            <!-- Title English -->
            <div class="mb-4">
                <label for="name_en" class="block opacity-50 text-sm font-medium text-gray-700">الاسم
                    بالانجليزي</label>
                <input type="text" id="name_en" name="name_en"
                    class="mt-1 w-full rounded-md bg-gray-100 px-2 py-1 hover:shadow outline-none focus:shadow" readonly>
            </div>

            <!-- Title Arabic -->
            <div class="mb-4">
                <label for="name_ar" class="block text-sm font-medium text-gray-700">الاسم بالعربي</label>
                <input type="text" id="name_ar" name="name_ar"
                    class="mt-1 w-full rounded-md bg-gray-100 px-2 py-1 hover:shadow outline-none focus:shadow" required>
                <?php $__errorArgs = ['name_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <input type="hidden" id="id" name="id">

            <div class="flex justify-between border-t border-gray-300 pt-2">
                <button type="button" id="modalSubmitBtn"
                    class="disableBtn px-2 py-1 text-xs bg-black rounded text-white"><?php echo e(__('dashboard.update')); ?></button>
                <button type="button" onclick="closeModal('editName')"
                    class="px-2 py-1 text-xs bg-white rounded text-black"><?php echo e(__('dashboard.close')); ?></button>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

    <?php echo $__env->make('dashboard.inc._toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    // Function to open modal and set its content
    function openModal(button) {
        // Read data from button's data attributes
        const modalId = button.getAttribute('data-modal-id');
        const nameEn = button.getAttribute('data-name-en');
        const nameAr = button.getAttribute('data-name-ar');
        const id = button.getAttribute('data-id');
        
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('block');
            modal.classList.remove('hidden');
        }

        // Set values in the modal form
        document.getElementById('name_en').value = nameEn;
        document.getElementById('name_ar').value = nameAr;
        document.getElementById('id').value = id;

        // Update on click submit function
        document.getElementById('modalSubmitBtn').onclick = () => submitEditName(id);
    }

    // Function to submit the edit form
    function submitEditName(id) {
        let route = "<?php echo e(route('dashboard.facilities.update')); ?>";
        const formData = new FormData();
        formData.append('name_ar', document.getElementById('name_ar').value); // Ensure this ID is correct
        formData.append('id', id);

        fetch(route, {
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                },
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update the corresponding element on the page
                    let columnName = document.getElementById('name_' + id);
                    if (columnName) {
                        columnName.innerHTML = data.name_en + ' / ' + data.name_ar;
                    }

                    // Clear form fields
                    document.getElementById('name_ar').value = '';
                    document.getElementById('id').value = '';

                    // Show success toast message
                    toast('toast-success', data.message);

                    // Close the modal
                    closeModal('editName');
                }
            })
            .catch(error => {
                console.error('Error:', error); // Add error handling
            });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NeferitiWebsite\resources\views\dashboard\facility.blade.php ENDPATH**/ ?>