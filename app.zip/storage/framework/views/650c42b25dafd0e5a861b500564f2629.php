<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginald3b387f4f5efe74d7afe13be62871c47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3b387f4f5efe74d7afe13be62871c47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="text-xl font-bold"><?php echo e(__('dashboard.blogs')); ?></div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $attributes = $__attributesOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $component = $__componentOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__componentOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>


    <div class="bg-white rounded-lg shadow p-6 h-full">
        <button onclick="window.location.href = '<?php echo e(route('dashboard.blogs.create')); ?>'"
            class="px-2 py-1 bg-black hover:bg-[#472A12] text-white mb-2 rounded-lg">
            <?php echo e(__('dashboard.create_blog')); ?>

        </button>

        <!-- Content here -->
        <div>

            <table class="shadow w-full rounded-lg overflow-hidden">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.title')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.product')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.status')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.order')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.created_at')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.actions')); ?></th>
                    </tr>
                </thead>
                <tbody id="tableData">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="row-<?php echo e($blog['id']); ?>" class="border-t border-gray-200">
                            <td class="py-2 px-4 text-start items-center">
                                <p><?php echo e($blog->title); ?></p>
                            </td>
                            <td class="py-2 px-4 text-start items-center">
                                <?php if($blog->product): ?>
                                    <a href="<?php echo e(route('dashboard.products.edit', $blog->product->id)); ?>"
                                        class="text-blue-500 hover:text-blue-700"><?php echo e($blog->product?->name); ?>

                                    </a>
                                <?php else: ?>
                                    عام
                                <?php endif; ?>
                            </td>
                            <td class="py-2 px-4 text-start items-center">
                                
                                <span class="cursor-pointer" >
                                    <?php echo e($blog->status ? __('dashboard.active') : __('dashboard.inactive')); ?>

                                </span>
                            </td>
                            <td class="py-2 px-4 text-start items-center">
                                <div class="flex gap-2 bg-blue-200 p-2 rounded-lg justify-center">
                                    <form action="<?php echo e(route('dashboard.blogs.up', $blog->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="fa-solid fa-arrow-up"></button>
                                    </form>
                                    <?php echo e($blog->order_number); ?>

                                    <form action="<?php echo e(route('dashboard.blogs.down', $blog->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="fa-solid fa-arrow-down"></button>
                                    </form>    
                                </div>
                            </td>
                            <td class="py-2 px-4 text-start items-center">
                                <?php echo e($blog->created_at->format('Y-m-d H:i')); ?>

                            </td>
                            <td class="py-2 px-4 ">
                                <div class="flex gap-2">
                                    <a href="<?php echo e(route('dashboard.blogs.edit', $blog->id)); ?>"
                                        class="fa-solid fa-pen-to-square hover:text-blue-500"></a>
                                        <form action="<?php echo e(route('dashboard.blogs.destroy', $blog->id)); ?>" method="POST"
                                            id="deleteBlogForm<?php echo e($blog->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <i role="button" onclick="confirmDelete('deleteBlogForm<?php echo e($blog->id); ?>', '<?php echo e(lang()); ?>')"
                                                class="fa-solid fa-trash hover:text-red-500"></i>
                                        </form>
    
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

                
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NeferitiWebsite\resources\views\dashboard\blogs\index.blade.php ENDPATH**/ ?>