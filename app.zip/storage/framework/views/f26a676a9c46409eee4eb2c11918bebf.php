<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginald3b387f4f5efe74d7afe13be62871c47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3b387f4f5efe74d7afe13be62871c47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="text-xl font-bold"><?php echo e(__('dashboard.testimonials')); ?></div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $attributes = $__attributesOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $component = $__componentOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__componentOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>

    <div class="bg-white rounded-lg shadow p-6 h-full">
        <button onclick="window.location.href = '<?php echo e(route('dashboard.testimonials.create')); ?>';"
            class="px-2 py-1 bg-black hover:bg-[#472A12] text-white mb-2 rounded-lg">
            <?php echo e(__('dashboard.create')); ?>

        </button>

        <!-- Content here -->
        <div>

            <table class="shadow w-full rounded-lg overflow-hidden">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.name')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.message')); ?></th>
                        <th class="py-2 px-4 text-start"><?php echo e(__('dashboard.actions')); ?></th>
                    </tr>
                </thead>
                <tbody id="tableData">
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="row-<?php echo e($testimonial->id); ?>" class="border-t border-gray-200">
                            <td class="py-2 px-4 text-start items-center">
                                <?php echo e($testimonial->name); ?>

                            </td>
                            <td class="py-2 px-4 text-start items-center">
                                <?php echo e($testimonial->description); ?>

                            </td>
                            <td class="py-2 px-4 text-start items-center">
                                <div class="flex gap-2 items-center">
                                    <form action="<?php echo e(route('dashboard.testimonials.destroy', $testimonial->id)); ?>" method="POST"
                                        id="deleteTestimonialForm<?php echo e($testimonial->id); ?>" class="flex items-center">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>   
                                        <i role="button" onclick="confirmDelete('deleteTestimonialForm<?php echo e($testimonial->id); ?>', '<?php echo e(lang()); ?>')"
                                            class="fa-solid fa-trash hover:text-red-500"></i>
                                    </form>
                                </div>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NeferitiWebsite\resources\views\dashboard\testimonials\index.blade.php ENDPATH**/ ?>