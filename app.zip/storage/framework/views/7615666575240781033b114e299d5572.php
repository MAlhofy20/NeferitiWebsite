

<?php $__env->startSection('content'); ?>
<div class="h-screen md:grid grid-cols-3">
    <div class="p-5 flex items-center justify-center shadow-2xl bg-gradient-to-bl from-[#b9fffa]  via-transparent">
        <form method="post" action="<?php echo e(route('login.check')); ?>" class="w-full">
            <?php echo csrf_field(); ?>
            <p class="text-2xl font-bold mb-10 text-black"><i class="fa-solid fa-lock ml-2"></i><?php echo e(__('dashboard.login')); ?></p>

            <div class="mb-4">
                <label for="email" class="block mb-1 text-black "><?php echo e(__('dashboard.email')); ?></label>
                <input type="email" id="email" name="email" class="w-full p-2 border bg-gray-100 rounded-lg">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label for="password" class="block mb-1 text-black"><?php echo e(__('dashboard.password')); ?></label>
                <input type="password" id="password" name="password" class="w-full p-2 border bg-gray-100 rounded-lg">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                
                <div class="flex gap-3">
                    <input type="checkbox" id="remember" name="remember" >
                    <label for="remember" class="block text-sm text-black"><?php echo e(__('dashboard.remember_me')); ?></label>
                </div>
            </div>

            <div class="justify-center flex flex-col">
                <button type="submit"  class="disableBtn px-4 py-2  bg-primary hover:bg-secondary text-white rounded-lg "><?php echo e(__('dashboard.login')); ?></button>
            </div>
        </form>
    </div>
    <div class="p-5 flex items-center justify-center col-span-2 bg-primary">
        <img class="w-[50%] rounded-lg" src="<?php echo e(asset('dash/images/4.png')); ?>">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NeferitiWebsite\resources\views\dashboard\auth\login.blade.php ENDPATH**/ ?>