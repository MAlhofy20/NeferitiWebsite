<!DOCTYPE html>
<html>
<head>
    <title>Notification Email</title>
</head>
<body>
    <h1>Test Notification</h1>
    <p>{{ $messageContent }}</p>
</body>
</html>
